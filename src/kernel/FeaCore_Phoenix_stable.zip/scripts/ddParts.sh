#!/tmp/busybox sh

dd if=/tmp/boot.img of=/dev/block/mmcblk0p8
dd if=/tmp/recovery.img of=/dev/block/mmcblk0p13


