#!/tmp/busybox sh

cat /dev/zero > /dev/block/mmcblk0p8
cat /dev/zero > /dev/block/mmcblk0p13

